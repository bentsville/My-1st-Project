# Frontend - Corporate Banking (React)

- Run: `npm install` then `npm start`
- The React app expects backend at /api/* (proxy). For development you can set up a proxy or run frontend with a simple server and use CORS in backend.
- Basic pages: Login, Accounts, Create PAY, Upload CSV, Transactions, Approvals, Print Preview.
