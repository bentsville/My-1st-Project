import React, {useState} from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

function App(){
  const [token, setToken] = useState(localStorage.getItem('token')||null);
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')||'null'));
  if(!token) return <Login onLogin={(t,u)=>{ setToken(t); setUser(u); localStorage.setItem('token',t); localStorage.setItem('user',JSON.stringify(u)); }} />;
  return <Dashboard token={token} user={user} onLogout={()=>{ setToken(null); setUser(null); localStorage.removeItem('token'); localStorage.removeItem('user'); }} />;
}
export default App;
