import React, {useState} from 'react';
import Accounts from './Accounts';
import CreatePayroll from './CreatePayroll';
import UploadCSV from './UploadCSV';
import TransactionsList from './TransactionsList';
import Approvals from './Approvals';
import PrintPreview from './PrintPreview';

export default function Dashboard({token,user,onLogout}){
  const [view,setView]=useState('accounts');
  const [previewHtml,setPreviewHtml]=useState(null);

  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
        <div className="container-fluid">
          <a className="navbar-brand" href="#">Corporate Channel</a>
          <div className="d-flex">
            <span className="me-3 text-white">Hello, {user?.fullName || user?.username}</span>
            <button className="btn btn-outline-light" onClick={onLogout}>Logout</button>
          </div>
        </div>
      </nav>

      <div className="container my-4">
        <div className="row">
          <div className="col-md-3">
            <div className="list-group">
              <button className={'list-group-item '+(view==='accounts'?'active':'')} onClick={()=>setView('accounts')}>Accounts & Balances</button>
              <button className={'list-group-item '+(view==='create'?'active':'')} onClick={()=>setView('create')}>Create PAY</button>
              <button className={'list-group-item '+(view==='upload'?'active':'')} onClick={()=>setView('upload')}>Quick Upload (CSV)</button>
              <button className={'list-group-item '+(view==='tx'?'active':'')} onClick={()=>setView('tx')}>My Transactions</button>
              <button className={'list-group-item '+(view==='approve'?'active':'')} onClick={()=>setView('approve')}>Approvals</button>
            </div>
          </div>
          <div className="col-md-9">
            {view==='accounts' && <Accounts token={token} />}
            {view==='create' && <CreatePayroll token={token} user={user} onPreview={(h)=>setPreviewHtml(h)} />}
            {view==='upload' && <UploadCSV token={token} user={user} />}
            {view==='tx' && <TransactionsList token={token} user={user} onPreview={(h)=>setPreviewHtml(h)} />}
            {view==='approve' && <Approvals token={token} user={user} onPreview={(h)=>setPreviewHtml(h)} />}
          </div>
        </div>
      </div>

      <PrintPreview html={previewHtml} onClose={()=>setPreviewHtml(null)} />
    </div>
  );
}
