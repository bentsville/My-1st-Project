import React from 'react';
export default function PrintPreview({html,onClose}){
  if(!html) return null;
  return (
    <div className="modal show" style={{display:'block',background:'rgba(0,0,0,0.5)'}}>
      <div className="modal-dialog modal-lg">
        <div className="modal-content">
          <div className="modal-header"><h5 className="modal-title">Print Preview</h5><button className="btn-close" onClick={onClose}></button></div>
          <div className="modal-body"><div dangerouslySetInnerHTML={{__html:html}} /></div>
          <div className="modal-footer"><button className="btn btn-primary" onClick={()=>{ window.print(); }}>Print</button><button className="btn btn-secondary" onClick={onClose}>Close</button></div>
        </div>
      </div>
    </div>
  );
}
