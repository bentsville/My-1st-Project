import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function Accounts(){
  const [accounts,setAccounts]=useState([]);
  useEffect(()=>{ axios.get('/api/balances').then(r=>setAccounts(r.data)); },[]);
  return (
    <div>
      <h4>Accounts & Balances</h4>
      <table className="table">
        <thead><tr><th>Account</th><th>Owner</th><th>Currency</th><th>Balance</th></tr></thead>
        <tbody>
          {accounts.map(a=>(
            <tr key={a.id}><td>{a.accountNumber}</td><td>{a.ownerName}</td><td>{a.currency}</td><td>{a.balance}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
