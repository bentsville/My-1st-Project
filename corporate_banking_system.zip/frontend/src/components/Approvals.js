import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function Approvals({user,onPreview}){
  const [txs,setTxs]=useState([]);
  useEffect(()=>{ axios.get('/api/transactions').then(r=>setTxs(r.data.filter(x=>x.status==='PENDING'))); },[]);
  const approve = async (id)=>{ await axios.post('/api/transactions/'+id+'/approve?approver='+user.username); setTxs(txs.filter(t=>t.id!==id)); alert('Approved'); };
  const print = async (t)=>{ const r=await axios.post('/api/transactions/'+t.id+'/print'); onPreview(r.data); };
  return (
    <div>
      <h4>Approvals</h4>
      <table className="table">
        <thead><tr><th>ID</th><th>Ref</th><th>From</th><th>To</th><th>Amount</th><th>Actions</th></tr></thead>
        <tbody>
          {txs.map(t=>(
            <tr key={t.id}><td>{t.id}</td><td>{t.reference}</td><td>{t.fromAccount}</td><td>{t.toAccount}</td><td>{t.amount}</td>
              <td>
                <button className="btn btn-sm btn-success me-2" onClick={()=>approve(t.id)}>Approve</button>
                <button className="btn btn-sm btn-secondary" onClick={()=>print(t)}>Print</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
