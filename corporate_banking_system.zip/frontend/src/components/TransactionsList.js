import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function TransactionsList({user,onPreview}){
  const [txs,setTxs]=useState([]);
  useEffect(()=>{ load(); },[]);
  const load = async ()=>{ const res = await axios.get('/api/transactions?username='+user.username); setTxs(res.data); };
  const edit = async (tx)=>{ const newAmount = prompt('New amount', tx.amount); if(!newAmount) return; await axios.put('/api/transactions/'+tx.id, {...tx, amount:newAmount}); load(); };
  const print = async (tx)=>{ const r = await axios.post('/api/transactions/'+tx.id+'/print'); onPreview(r.data); };
  return (
    <div>
      <h4>My Transactions</h4>
      <table className="table">
        <thead><tr><th>ID</th><th>Ref</th><th>From</th><th>To</th><th>Amount</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {txs.map(t=>(
            <tr key={t.id}>
              <td>{t.id}</td><td>{t.reference}</td><td>{t.fromAccount}</td><td>{t.toAccount}</td><td>{t.amount}</td><td>{t.status}</td>
              <td>
                <button className="btn btn-sm btn-outline-primary me-1" onClick={()=>edit(t)}>Edit</button>
                <button className="btn btn-sm btn-outline-secondary me-1" onClick={()=>print(t)}>Print</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
