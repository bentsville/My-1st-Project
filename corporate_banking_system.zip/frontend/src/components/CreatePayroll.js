import React, {useState, useEffect} from 'react';
import axios from 'axios';

export default function CreatePayroll({user,onPreview}){
  const [accounts,setAccounts]=useState([]);
  const [form,setForm]=useState({reference:'',fromAccount:'',toAccount:'',amount:'',currency:'MYR',status:'PENDING'});
  useEffect(()=>{ axios.get('/api/accounts').then(r=>setAccounts(r.data)); },[]);
  const submit = async ()=> {
    if(!form.fromAccount || !form.toAccount || !form.amount) { alert('Please fill required fields'); return; }
    const payload = {...form, createdBy: user.username};
    const res = await axios.post('/api/transactions', payload);
    alert('Transaction created: '+res.data.id);
  };
  const saveDraft = async ()=> {
    const payload = {...form, status:'DRAFT', createdBy: user.username};
    const res = await axios.post('/api/transactions', payload);
    alert('Draft saved: '+res.data.id);
  };
  return (
    <div>
      <h4>Create Payroll Payment (PAY)</h4>
      <div className="card p-3">
        <div className="mb-2"><label>Reference</label><input className="form-control" value={form.reference} onChange={e=>setForm({...form,reference:e.target.value})} /></div>
        <div className="mb-2"><label>From Account</label>
          <select className="form-select" value={form.fromAccount} onChange={e=>setForm({...form,fromAccount:e.target.value})}>
            <option value="">-- select --</option>
            {accounts.map(a=> <option key={a.id} value={a.accountNumber}>{a.accountNumber} ({a.currency}) - {a.ownerName}</option>)}
          </select>
        </div>
        <div className="mb-2"><label>To Account</label><input className="form-control" value={form.toAccount} onChange={e=>setForm({...form,toAccount:e.target.value})} /></div>
        <div className="mb-2"><label>Amount</label><input type="number" className="form-control" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} /></div>
        <div className="mb-2"><label>Currency</label><input className="form-control" value={form.currency} onChange={e=>setForm({...form,currency:e.target.value})} /></div>
        <div className="d-flex gap-2">
          <button className="btn btn-primary" onClick={submit}>Submit Payment</button>
          <button className="btn btn-outline-secondary" onClick={saveDraft}>Save as Draft</button>
        </div>
      </div>
    </div>
  );
}
