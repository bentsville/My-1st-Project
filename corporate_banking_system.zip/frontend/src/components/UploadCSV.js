import React, {useState} from 'react';
import axios from 'axios';

export default function UploadCSV({user}){
  const [file,setFile]=useState(null);
  const [batchName,setBatchName]=useState('');

  const upload = async ()=>{
    if(!file) { alert('Select CSV file'); return; }
    let batchId = null;
    if(batchName){
      const b = await axios.post('/api/batches',{name:batchName, createdBy:user.username});
      batchId = b.data.id;
    }
    const fd = new FormData();
    fd.append('file', file);
    fd.append('createdBy', user.username);
    if(batchId) fd.append('batchId', batchId);
    const res = await axios.post('/api/upload-csv', fd);
    alert('Upload result: '+JSON.stringify(res.data));
  };

  return (
    <div>
      <h4>Quick Payment Creation (CSV)</h4>
      <div className="card p-3">
        <div className="mb-2"><label>Batch Name (optional)</label><input className="form-control" value={batchName} onChange={e=>setBatchName(e.target.value)} /></div>
        <div className="mb-2"><label>CSV file (reference,fromAccount,toAccount,amount,currency)</label><input type="file" accept=".csv" className="form-control" onChange={e=>setFile(e.target.files[0])} /></div>
        <button className="btn btn-primary" onClick={upload}>Upload CSV</button>
      </div>
    </div>
  );
}
