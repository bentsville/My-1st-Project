# Corporate Banking System - Starter

This repository contains a starter full-stack corporate banking application:
- Backend: Java 17 + Spring Boot (Maven)
- Frontend: React + Bootstrap

## Setup (local)
1. Ensure Java 17, Maven, Node.js/npm, and PostgreSQL are installed.
2. Create PostgreSQL database: `corporate_db` and ensure the server listens on port 5412.
   - Username: postgress
   - Password: password
3. Backend:
   - cd backend
   - mvn clean package
   - mvn spring-boot:run
4. Frontend:
   - cd frontend
   - npm install
   - npm start

Demo:
- POST /api/auth/register-demo to create demo users (corpuser/password, approver/password)
- POST /api/accounts/demo to create demo accounts
- Use the React UI to login and exercise flows.

Notes:
- This is a demonstration scaffold. For production: use encrypted passwords, proper JWT validation, role-based access control, validations, input sanitization, and HTTPS.
