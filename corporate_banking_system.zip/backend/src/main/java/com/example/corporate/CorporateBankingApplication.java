package com.example.corporate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorporateBankingApplication {
    public static void main(String[] args) {
        SpringApplication.run(CorporateBankingApplication.class, args);
    }
}
