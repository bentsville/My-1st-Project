package com.example.corporate.service;

import com.example.corporate.model.User;
import com.example.corporate.repo.UserRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    private final UserRepository repo;
    private final int MAX_FAILED = 3;
    public UserService(UserRepository repo){this.repo=repo;}

    public Optional<User> findByUsername(String username){return repo.findByUsername(username);}

    public User createIfNotExists(User u){
        return repo.findByUsername(u.getUsername()).orElseGet(()->repo.save(u));
    }

    public void recordFailedLogin(User u){
        u.setFailedLoginAttempts(u.getFailedLoginAttempts()+1);
        if(u.getFailedLoginAttempts()>=MAX_FAILED){
            u.setLocked(true);
        }
        repo.save(u);
    }

    public void resetFailed(User u){
        u.setFailedLoginAttempts(0);
        u.setLocked(false);
        repo.save(u);
    }
}
