package com.example.corporate.controller;

import com.example.corporate.model.*;
import com.example.corporate.repo.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class TransactionController {
    private final AccountRepository accountRepo;
    private final PayTransactionRepository txRepo;
    private final BatchRepository batchRepo;

    public TransactionController(AccountRepository accountRepo, PayTransactionRepository txRepo, BatchRepository batchRepo){
        this.accountRepo=accountRepo; this.txRepo=txRepo; this.batchRepo=batchRepo;
    }

    @GetMapping("/accounts")
    public List<Account> accounts(){ return accountRepo.findAll(); }

    @PostMapping("/accounts/demo")
    public ResponseEntity<?> createDemoAccounts(){
        if(accountRepo.findAll().isEmpty()){
            Account a1 = Account.builder().accountNumber("100-000-001").currency("MYR").balance(new BigDecimal("100000.00")).ownerName("Corp A").build();
            Account a2 = Account.builder().accountNumber("100-000-002").currency("USD").balance(new BigDecimal("50000.00")).ownerName("Corp A").build();
            accountRepo.save(a1); accountRepo.save(a2);
        }
        return ResponseEntity.ok(Map.of("status","demo accounts created"));
    }

    @PostMapping("/transactions")
    public PayTransaction createTransaction(@RequestBody PayTransaction tx){
        if(tx.getStatus()==null) tx.setStatus("PENDING");
        tx.setCreatedAt(LocalDateTime.now());
        return txRepo.save(tx);
    }

    @GetMapping("/transactions")
    public List<PayTransaction> listTransactions(@RequestParam(required=false) String username){
        if(username==null) return txRepo.findAll();
        return txRepo.findByCreatedBy(username);
    }

    @GetMapping("/transactions/{id}")
    public ResponseEntity<?> getTx(@PathVariable Long id){
        var opt = txRepo.findById(id);
        return opt.<ResponseEntity<?>>map(ResponseEntity::ok).orElseGet(()->ResponseEntity.notFound().build());
    }

    @PutMapping("/transactions/{id}")
    public ResponseEntity<?> updateTx(@PathVariable Long id, @RequestBody PayTransaction updated){
        var opt = txRepo.findById(id);
        if(opt.isEmpty()) return ResponseEntity.notFound().build();
        PayTransaction tx = opt.get();
        if("APPROVED".equals(tx.getStatus())) return ResponseEntity.status(400).body(Map.of("error","Cannot edit approved transaction"));
        tx.setAmount(updated.getAmount());
        tx.setToAccount(updated.getToAccount());
        tx.setReference(updated.getReference());
        txRepo.save(tx);
        return ResponseEntity.ok(tx);
    }

    @PostMapping("/transactions/{id}/print")
    public ResponseEntity<String> printPreview(@PathVariable Long id){
        var opt = txRepo.findById(id);
        if(opt.isEmpty()) return ResponseEntity.notFound().build();
        PayTransaction tx = opt.get();
        String html = "<html><body><h2>Transaction #"+tx.getId()+"</h2>"+
                "<p>From: "+tx.getFromAccount()+"</p>"+
                "<p>To: "+tx.getToAccount()+"</p>"+
                "<p>Amount: "+tx.getAmount()+" "+tx.getCurrency()+"</p>"+
                "</body></html>";
        return ResponseEntity.ok().contentType(MediaType.TEXT_HTML).body(html);
    }

    @PostMapping("/upload-csv")
    public ResponseEntity<?> uploadCsv(@RequestParam("file") MultipartFile file, @RequestParam String createdBy, @RequestParam(required=false) Long batchId) throws Exception{
        List<PayTransaction> created = new ArrayList<>();
        try(var br = new BufferedReader(new InputStreamReader(file.getInputStream()))){
            String line;
            while((line = br.readLine())!=null){
                if(line.trim().isEmpty()) continue;
                // simple csv: reference,fromAccount,toAccount,amount,currency
                String[] parts = line.split(",");
                if(parts.length<5) continue;
                PayTransaction tx = PayTransaction.builder()
                        .reference(parts[0].trim())
                        .fromAccount(parts[1].trim())
                        .toAccount(parts[2].trim())
                        .amount(new BigDecimal(parts[3].trim()))
                        .currency(parts[4].trim())
                        .status("PENDING")
                        .createdBy(createdBy)
                        .createdAt(LocalDateTime.now())
                        .batchId(batchId)
                        .build();
                created.add(txRepo.save(tx));
            }
        }
        return ResponseEntity.ok(Map.of("created",created.size()));
    }

    @PostMapping("/batches")
    public Batch createBatch(@RequestBody Batch b){
        b.setCreatedAt(LocalDateTime.now());
        return batchRepo.save(b);
    }

    @GetMapping("/batches")
    public List<Batch> listBatches(){ return batchRepo.findAll(); }

    @PostMapping("/transactions/{id}/approve")
    public ResponseEntity<?> approve(@PathVariable Long id, @RequestParam String approver){
        var opt = txRepo.findById(id);
        if(opt.isEmpty()) return ResponseEntity.notFound().build();
        PayTransaction tx = opt.get();
        tx.setStatus("APPROVED");
        txRepo.save(tx);
        return ResponseEntity.ok(Map.of("status","approved"));
    }

    @GetMapping("/balances")
    public List<Account> balances(){ return accountRepo.findAll(); }

    @GetMapping("/statement/{accountNumber}")
    public ResponseEntity<?> statement(@PathVariable String accountNumber, @RequestParam String from, @RequestParam String to){
        // For demo, return txs where fromAccount==accountNumber or toAccount==accountNumber
        List<PayTransaction> all = txRepo.findAll();
        var filtered = all.stream().filter(tx -> accountNumber.equals(tx.getFromAccount()) || accountNumber.equals(tx.getToAccount())).collect(Collectors.toList());
        return ResponseEntity.ok(filtered);
    }
}
