package com.example.corporate.repo;

import com.example.corporate.model.PayTransaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PayTransactionRepository extends JpaRepository<PayTransaction, Long> {
    List<PayTransaction> findByCreatedBy(String username);
    List<PayTransaction> findByStatus(String status);
}
