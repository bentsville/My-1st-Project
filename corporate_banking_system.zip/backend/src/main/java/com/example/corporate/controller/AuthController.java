package com.example.corporate.controller;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.example.corporate.model.User;
import com.example.corporate.service.UserService;
import com.example.corporate.repo.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserService userService;
    private final UserRepository userRepo;

    @Value("${jwt.secret}")
    private String jwtSecret;
    @Value("${jwt.expirationMs}")
    private Long jwtExp;

    public AuthController(UserService userService, UserRepository userRepo){
        this.userService = userService; this.userRepo = userRepo;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        String username = body.get("username");
        String password = body.get("password");
        var opt = userRepo.findByUsername(username);
        if(opt.isEmpty()) return ResponseEntity.status(401).body(Map.of("error","Invalid credentials"));
        User u = opt.get();
        if(u.isLocked()) return ResponseEntity.status(403).body(Map.of("error","Account locked after 3 failed attempts"));
        if(!u.getPassword().equals(password)){
            userService.recordFailedLogin(u);
            return ResponseEntity.status(401).body(Map.of("error","Invalid credentials"));
        }
        userService.resetFailed(u);
        Algorithm alg = Algorithm.HMAC256(jwtSecret);
        String token = JWT.create()
                .withSubject(u.getUsername())
                .withClaim("role", u.getRole())
                .withExpiresAt(new Date(System.currentTimeMillis()+jwtExp))
                .sign(alg);
        return ResponseEntity.ok(Map.of("token", token, "username", u.getUsername(), "fullName", u.getFullName()));
    }

    // simple registration helper to create demo users
    @PostMapping("/register-demo")
    public ResponseEntity<?> registerDemo(){
        User u = User.builder().username("corpuser").password("password").fullName("Corporate User").role("ROLE_USER").build();
        User a = User.builder().username("approver").password("password").fullName("Approver User").role("ROLE_APPROVER").build();
        userService.createIfNotExists(u);
        userService.createIfNotExists(a);
        return ResponseEntity.ok(Map.of("status","demo users created"));
    }
}
