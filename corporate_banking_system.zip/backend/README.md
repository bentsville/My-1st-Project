# Backend - Corporate Banking (Spring Boot)

## Run
- Requires Java 17 and Maven.
- Ensure PostgreSQL is running on localhost:5412 with database `corporate_db` and user `postgress` password `password`.
- Build: `mvn clean package`
- Run: `mvn spring-boot:run`

Demo endpoints:
- POST /api/auth/register-demo -> create demo users (corpuser, approver)
- POST /api/accounts/demo -> create demo accounts
- Other endpoints under /api/*

Note: passwords are plain text in this demo. Swap to bcrypt and improve security for production.
