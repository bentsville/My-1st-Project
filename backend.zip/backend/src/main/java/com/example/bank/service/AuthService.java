package com.example.bank.service;

import com.example.bank.model.User;
import com.example.bank.repository.UserRepository;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public Optional<User> findById(Long id){ return userRepository.findById(id); }

    public User registerNewUser(String username, String password) {
        if (userRepository.findByUsername(username).isPresent()) {
            throw new IllegalArgumentException("Username already exists");
        }
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPasswordHash(passwordEncoder.encode(password)); // Hash the password

        // Set roles or other default values
        return userRepository.save(newUser);
    }

    public LoginResult login(String username, String password) {
        User user = userRepository.findByUsername(username).orElse(null);
        if (user == null) {
            return new LoginResult(false, "Invalid username");
        }
//        if (user.isAccountLocked()) {
//            return new LoginResult(false, "Account locked. Contact admin.");
//        }
        boolean ok = BCrypt.checkpw(password, user.getPasswordHash());

        if (ok) {
            user.setFailedAttempts(0);
            userRepository.save(user);
            return new LoginResult(true, "Login successful", user.getId(), user.getRole());
        } else {
            int attempts = user.getFailedAttempts() + 1;
            user.setFailedAttempts(attempts);
            if (attempts >= 3) user.setAccountLocked(true);
            userRepository.save(user);
            int left = Math.max(0, 3 - attempts);
            return new LoginResult(false, "Invalid password. Attempts left: " + left);
        }
    }

    public static class LoginResult {
        public boolean success;
        public String message;
        public Long userId;
        public String role;
        public LoginResult(boolean success, String message) {
            this.success = success; this.message = message;
        }
        public LoginResult(boolean success, String message, Long userId, String role) {
            this.success = success; this.message = message; this.userId = userId; this.role = role;
        }
    }
}
