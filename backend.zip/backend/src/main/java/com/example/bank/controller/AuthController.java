package com.example.bank.controller;


import com.example.bank.service.AuthService;
import com.example.bank.repository.UserRepository;
import com.example.bank.utils.JwtService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    private final JwtService jwtService;

    public AuthController(AuthService authService, UserRepository userRepository, JwtService jwtService) {
        this.authService = authService;
        this.userRepository = userRepository;
        this.jwtService = jwtService;
    }



//    @PostMapping("/login")
//    public Map<String, Object> login(@RequestBody Map<String,String> payload, HttpSession session) {
//        String username = payload.get("username");
//        String password = payload.get("password");
//
//        var result = authService.login(username, password);
//        if (result.success) {
//            session.setAttribute("USER_ID", result.userId);
//            session.setAttribute("ROLE", result.role);
//        }
//        return Map.of("success", result.success, "message", result.message);
//    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");

        var result = authService.login(username, password);

        if (result.success) {
            // Generate a JWT for the authenticated user
            String token = jwtService.generateToken(username, result.role);

            // Return the user information and the JWT to the client
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", result.message);
            response.put("token", token);
            response.put("username", username);
            response.put("role", result.role);

            return ResponseEntity.ok(response);
        } else {
            // For failed login, return an appropriate status code (e.g., 401 Unauthorized)
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                    "success", false,
                    "message", result.message
            ));
        }
    }


    @PostMapping("/create")
    public Map<String, Object> create(@RequestBody Map<String,String> payload, HttpSession session) {
        String username = payload.get("username");
        String password = payload.get("password");

        var result = authService.registerNewUser(username, password);

        return Map.of("success", result.getUsername(), "User Id", result.getId());
    }



    @GetMapping("/logout")
    public Map<String, String> logout(HttpSession session) {
        session.invalidate();
        return Map.of("message", "Logged out");
    }

    @GetMapping("/me")
    public Map<String, Object> me(HttpSession session) {
        Object uid = session.getAttribute("USER_ID");
        return Map.of("userId", uid == null ? null : uid);
    }
}
