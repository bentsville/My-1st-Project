package com.example.bank.controller;

import com.example.bank.model.Account;
import com.example.bank.model.Transaction;
import com.example.bank.model.User;
import com.example.bank.service.AccountService;
import com.example.bank.service.TransactionService;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountService accountService;
    private final TransactionService transactionService;

    public AccountController(AccountService accountService, TransactionService transactionService) {
        this.accountService = accountService;
        this.transactionService = transactionService;
    }


    @GetMapping
    public List<Account> myAccounts(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Long userId = ((User)authentication.getPrincipal()).getId();
        return accountService.myAccounts(userId);
    }



    @GetMapping("/{id}/statement")
    public List<Transaction> statement(@PathVariable Long id,
                                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                                       @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to){
        return transactionService.statement(id, from, to);
    }

    @GetMapping("/{id}/statement/export")
    public void exportCsv(@PathVariable Long id,
                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                          @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                          HttpServletResponse response) throws Exception {
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition","attachment; filename=statement.csv");
        List<Transaction> txns = transactionService.statement(id, from, to);
        try(PrintWriter pw = response.getWriter()){
            pw.println("id,beneficiaryName,beneficiaryAccount,amount,status,createdAt");
            for (Transaction t: txns){
                pw.printf("%d,%s,%s,%s,%s,%s%n", t.getId(), t.getBeneficiaryName(), t.getBeneficiaryAccount(), t.getAmount().toPlainString(), t.getStatus(), t.getCreatedAt().toString());
            }
        }
    }
}
