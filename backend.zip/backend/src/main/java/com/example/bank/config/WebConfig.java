package com.example.bank.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

//    @Override
//    public void addInterceptors(InterceptorRegistry registry) {
//        registry.addInterceptor(new AuthInterceptor())
//                .addPathPatterns("/api/**")
//                .excludePathPatterns("/api/auth/login", "/api/auth/logout", "/api/auth/create", "/api/auth/me", "/api/users");
//    }
//
//    static class AuthInterceptor implements HandlerInterceptor {
//        @Override
//        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
//            Object userId = request.getSession().getAttribute("USER_ID");
//            if (userId == null) {
//                response.setStatus(401);
//                response.getWriter().write("{\"error\":\"Unauthorized\"}");
//                return false;
//            }
//            return true;
//        }
//    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**") // Apply CORS to paths starting with /api/
                        .allowedOrigins("http://localhost:3000") // Specify allowed origins
                        .allowedMethods("GET", "POST", "PUT", "DELETE") // Specify allowed HTTP methods
                        .allowedHeaders("Authorization", "Content-Type") // Allow all headers
                        .allowCredentials(true) // Allow sending of cookies and authentication headers
                        .maxAge(3600); // Cache preflight requests for 1 hour
            }
        };
    }
}
