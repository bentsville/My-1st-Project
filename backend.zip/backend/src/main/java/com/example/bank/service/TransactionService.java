package com.example.bank.service;

import com.example.bank.model.*;
import com.example.bank.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import jakarta.transaction.Transactional;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TransactionService {
    private final TransactionRepository txnRepo;
    private final AccountRepository accountRepo;
    private final BatchRepository batchRepo;
    private final UserRepository userRepo;

    public TransactionService(TransactionRepository txnRepo, AccountRepository accountRepo, BatchRepository batchRepo, UserRepository userRepo) {
        this.txnRepo = txnRepo;
        this.accountRepo = accountRepo;
        this.batchRepo = batchRepo;
        this.userRepo = userRepo;
    }

    @Transactional
    public Transaction createTransaction(Long userId, Transaction transactionRequest, boolean submit) {
        // 1. Find the user entity
        User owner = userRepo.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + userId));

        // 2. Create and populate a new Transaction entity
        Transaction newTransaction = new Transaction();
        newTransaction.setOwner(owner);
        newTransaction.setAmount(transactionRequest.getAmount());
        newTransaction.setBeneficiaryAccount(transactionRequest.getBeneficiaryAccount());
        newTransaction.setBeneficiaryName(transactionRequest.getBeneficiaryName());
        newTransaction.setType(transactionRequest.getType());
        newTransaction.setAccount(transactionRequest.getAccount()); // Assuming account is passed correctly
        newTransaction.setBaseCurrency(transactionRequest.getBaseCurrency());
        newTransaction.setAccountCurrency(transactionRequest.getAccountCurrency());

        // Set the status based on the `submit` flag
        newTransaction.setStatus(submit ? "SUBMITTED" : "DRAFT");

        // The @PrePersist and @PreUpdate lifecycle annotations in your Transaction model will handle
        // createdAt and updatedAt automatically.

        // 3. Save the new transaction and return the persisted entity
        return txnRepo.save(newTransaction);
    }


    public Transaction createOrUpdate(Long userId, Transaction t, boolean submit) {
        User u = userRepo.findById(userId).orElseThrow();
        t.setOwner(u);
        if (t.getId() == null) {
            t.setStatus(submit ? "SUBMITTED" : "DRAFT");
        } else if (submit) {
            t.setStatus("SUBMITTED");
        }
        return txnRepo.save(t);
    }

    public List<Transaction> uploadCsv(Long userId, MultipartFile file, String batchName) throws Exception {
        User u = userRepo.findById(userId).orElseThrow();
        Batch batch = new Batch();
        batch.setName(batchName == null ? "Batch-" + Instant.now().toString() : batchName);
        batch.setOwner(u);
        batch = batchRepo.save(batch);

        List<Transaction> created = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            int row = 0;
            while ((line = br.readLine()) != null) {
                row++;
                if (row == 1 && line.toLowerCase().contains("account_number")) continue; // header
                String[] parts = line.split(",");
                if (parts.length < 6) continue;
                String accountNumber = parts[0].trim();
                String type = parts[1].trim();
                String beneficiaryName = parts[2].trim();
                String beneficiaryAcct = parts[3].trim();
                BigDecimal amount = new BigDecimal(parts[4].trim());
                String currency = parts[5].trim();

                Account acct = accountRepo.findByAccountNumber(accountNumber);
                if (acct == null) continue;

                Transaction t = new Transaction();
                t.setOwner(u);
                t.setAccount(acct);
                t.setBatch(batch);
                t.setType(type);
                t.setBeneficiaryName(beneficiaryName);
                t.setBeneficiaryAccount(beneficiaryAcct);
                t.setAmount(amount);
                t.setBaseCurrency(currency);
                t.setAccountCurrency(acct.getCurrency());
                t.setStatus("DRAFT");
                created.add(txnRepo.save(t));
            }
        }
        return created;
    }

    public List<Transaction> findAllByUser(Long userId) {
        User u = userRepo.findById(userId).orElseThrow();
        return txnRepo.findByOwner(u);
    }

    public List<Transaction> findPendingApprovals(Long userId) {
        User u = userRepo.findById(userId).orElseThrow();
        return txnRepo.findByOwnerAndStatus(u, "SUBMITTED");
    }

    public Transaction approve(Long id) {
        Transaction t = txnRepo.findById(id).orElseThrow();
        t.setStatus("APPROVED");
        return txnRepo.save(t);
    }

    public Transaction reject(Long id) {
        Transaction t = txnRepo.findById(id).orElseThrow();
        t.setStatus("REJECTED");
        return txnRepo.save(t);
    }

    public List<Transaction> statement(Long accountId, Instant from, Instant to) {
        Account acct = accountRepo.findById(accountId).orElseThrow();
        return txnRepo.findByAccountAndCreatedAtBetween(acct, from, to);
    }

    public Transaction updateTransaction(Long id, Long userId, Transaction t) {
        User u = userRepo.findById(userId).orElseThrow();
        t.setOwner(u);

        t.setStatus("SUBMITTED");

        return txnRepo.save(t);

    }
}
