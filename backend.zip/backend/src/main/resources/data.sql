INSERT INTO users (id, username, password_hash, failed_attempts, account_locked, role) VALUES
(1, 'demo', '$2a$10$7a7r3xJx1q5M9pXh6n74uO1o0xfu0gA9xn7s/t2jYb3x7r5m1k1g2', 0, false, 'ADMIN')
ON CONFLICT DO NOTHING;

INSERT INTO accounts (owner_id, account_number, currency, balance)
VALUES (
    (SELECT id FROM users WHERE username = 'test'),
    '1234567890',
    'USD',
    1000.00
);
