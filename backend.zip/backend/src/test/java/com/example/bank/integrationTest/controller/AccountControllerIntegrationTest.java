package com.example.bank.integrationTest.controller;

import com.example.bank.model.User;
import com.example.bank.repository.UserRepository; // Assuming you have a UserRepository
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;


import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// Use @SpringBootTest for integration testing
@SpringBootTest
@AutoConfigureMockMvc // This annotation is needed to inject MockMvc with @SpringBootTest
@Transactional // Ensures the database is rolled back after each test
public class AccountControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private UserRepository userRepository; // Use a real UserRepository

    // AccountService is a real bean, no need for @MockBean
    // private AccountService accountService;

    @Test
    void shouldReturnAccountsWhenLoggedInAndUserExistsInDb() throws Exception {
        // Create a real user and save it to the database
        User testUser = new User();

        testUser.setId(2L);
        testUser.setUsername("test");
        // Set necessary user properties (e.g., username, password etc.)
        userRepository.save(testUser);

        // Your AccountController logic should find this user based on the session user ID
        // Note: The AccountService is no longer mocked and will use the real database.

        // Use the saved user's ID
        Long userId = testUser.getId();

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("USER_ID", userId);

        String responseBody = mockMvc.perform(get("/api/accounts")
                        .session(session)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andReturn()
                .getResponse()
                .getContentAsString();

        System.out.println(responseBody);
    }
}
