package com.example.bank.unitTest.builder;

import com.example.bank.model.User;

public class UserBuilder {
    private Long id = 1L;
    private String username = "test";

    public static UserBuilder anUser() {
        return new UserBuilder();
    }

    public UserBuilder withId(Long id) {
        this.id = id;
        return this;
    }

    public UserBuilder withUsername(String username) {
        this.username = username;
        return this;
    }

    public User build() {
        User user = new User();
        user.setId(this.id);
        user.setUsername(this.username);
        // Set other properties with defaults if needed
        return user;
    }
}
