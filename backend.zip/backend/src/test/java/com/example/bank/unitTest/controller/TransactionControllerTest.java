package com.example.bank.unitTest.controller;

import com.example.bank.controller.AccountController;
import com.example.bank.controller.TransactionController;
import com.example.bank.model.Account;
import com.example.bank.model.Batch;
import com.example.bank.model.Transaction;
import com.example.bank.model.User;
import com.example.bank.service.AccountService;
import com.example.bank.service.TransactionService;
import com.example.bank.unitTest.builder.UserBuilder;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(TransactionController.class)
public class TransactionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AccountService accountService;

    @MockBean
    private TransactionService transactionService;

    @MockBean
    private User user;

    @MockBean
    private Batch batch;


    /**
     * Create or update Transactions
     * */

    /**
     * Get individual transaction of logged in user
     * */

    /**
     * Get all transactions of logged in user
     * */
    @Test
    void shouldReturnTransactionsWhenLoggedIn() throws Exception {
        Long userId = 2L;

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("USER_ID", userId);

        // All test data is created locally within the test method
        User mockUser = UserBuilder.anUser().build();
        Account mockAccount = new Account(1L, mockUser, "01", "MYR", BigDecimal.valueOf(123L));
        Batch mockBatch = new Batch();
        Instant now = Instant.now();

        List<Transaction> mockTransactions = Arrays.asList(
                new Transaction(1L, mockUser, mockAccount, mockBatch, "PAY", "beneficiary Name", "beneficiary Account", BigDecimal.valueOf(123L), "MYR", "MYR", "Pending", now, now),
                new Transaction(2L, mockUser, mockAccount, mockBatch, "PAY", "beneficiary Name", "beneficiary Account", BigDecimal.valueOf(123L), "MYR", "MYR", "Pending", now, now)
        );

        when(transactionService.findAllByUser(userId)).thenReturn(mockTransactions);

        mockMvc.perform(get("/api/transactions")
                        .session(session)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(2)))
                .andExpect(jsonPath("$[0].type", is("PAY")));

        verify(transactionService, times(1)).findAllByUser(userId);
    }
}
