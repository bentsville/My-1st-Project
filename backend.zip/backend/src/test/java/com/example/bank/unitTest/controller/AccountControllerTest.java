package com.example.bank.unitTest.controller;

import com.example.bank.controller.AccountController;
import com.example.bank.model.Account;
import com.example.bank.model.Batch;
import com.example.bank.model.Transaction;
import com.example.bank.model.User;
import com.example.bank.service.AccountService;
import com.example.bank.service.TransactionService;
import com.example.bank.unitTest.builder.UserBuilder; // Import the UserBuilder
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(AccountController.class)
public class AccountControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AccountService accountService;

    @MockBean
    private TransactionService transactionService;

    @MockBean
    private User user;

    @MockBean
    private Batch batch;

    @Test
    void shouldReturnAccountsWhenLoggedIn() throws Exception{
        Long userId = 2L;

        MockHttpSession session = new MockHttpSession();
        session.setAttribute("USER_ID", userId);

        // Using the builder for cleaner test data creation
        User mockUser = UserBuilder.anUser().build();

        List<Account> mockAccounts = Arrays.asList(
                new Account(1L, mockUser,"01","MYR", BigDecimal.valueOf(123L))
        );
        when(accountService.myAccounts(userId)).thenReturn(mockAccounts);

        mockMvc.perform(get("/api/accounts")
                        .session(session)
                        .accept(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$", hasSize(1)))
                .andReturn()
                .getResponse()
                .getContentAsString();

        verify(accountService, times(1)).myAccounts(userId);
    }


}
