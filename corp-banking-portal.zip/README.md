# Corporate Banking Portal (Prototype)

**Stack:** Java 17 + Spring Boot 3, PostgreSQL, JPA, Thymeleaf (for print), Bootstrap static UI.

## Features implemented
- Login with account lock after 3 failed attempts
- Create PAY transactions (draft or submit)
- Quick upload via CSV (creates a Batch & transactions)
- List transactions, submit, approve/reject
- Multi-transaction print (HTML preview with Thymeleaf)
- Accounts & balances
- Statements with drilldown + CSV export

## Prereqs
- Java 17
- Maven
- PostgreSQL running locally

Create DB & user (example):
```sql
CREATE DATABASE corpbank;
CREATE USER postgres WITH PASSWORD 'postgres';
GRANT ALL PRIVILEGES ON DATABASE corpbank TO postgres;
```

Update credentials in `backend/src/main/resources/application.properties` if needed.

## Run
```bash
cd backend
mvn spring-boot:run
```

Open:
- http://localhost:8080/login.html  (user: **demo**, password: **password**)
- Dashboard shows accounts, create transactions, upload CSV, manage & approve, print, statements.

## CSV Upload format
```
account_number,type,beneficiary_name,beneficiary_account,amount,currency
123-456-789,PAY,Ali,MY123456,1200.00,MYR
123-456-789,PAY,Siti,MY789012,1500.50,MYR
```

## Notes
- This is a minimal prototype to satisfy the user stories. Tighten validations, add proper RBAC, and real backoffice integration in production.
