INSERT INTO users (id, username, password_hash, failed_attempts, account_locked, role) VALUES
(1, 'demo', '$2a$10$7a7r3xJx1q5M9pXh6n74uO1o0xfu0gA9xn7s/t2jYb3x7r5m1k1g2', 0, false, 'ADMIN')
ON CONFLICT DO NOTHING;

INSERT INTO accounts (id, owner_id, account_number, currency, balance) VALUES
(1, 1, '123-456-789', 'MYR', 100000.00),
(2, 1, '987-654-321', 'USD', 25000.00)
ON CONFLICT DO NOTHING;
