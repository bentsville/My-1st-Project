package com.example.bank.repository;

import com.example.bank.model.Transaction;
import com.example.bank.model.User;
import com.example.bank.model.Account;
import com.example.bank.model.Batch;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.Instant;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByOwner(User owner);
    List<Transaction> findByOwnerAndStatus(User owner, String status);
    List<Transaction> findByAccountAndCreatedAtBetween(Account account, Instant start, Instant end);
    List<Transaction> findByBatch(Batch batch);
}
