package com.example.bank.controller;

import com.example.bank.model.Transaction;
import com.example.bank.service.TransactionService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @PostMapping
    public Transaction createOrUpdate(@RequestBody @Valid Transaction t,
                                      @RequestParam(defaultValue = "false") boolean submit,
                                      HttpSession session) {
        Long userId = (Long) session.getAttribute("USER_ID");
        return transactionService.createOrUpdate(userId, t, submit);
    }

    @GetMapping
    public List<Transaction> list(HttpSession session){
        Long userId = (Long) session.getAttribute("USER_ID");
        return transactionService.findAllByUser(userId);
    }

    @PostMapping(value="/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> upload(@RequestPart("file") MultipartFile file,
                                      @RequestParam(required = false) String batchName,
                                      HttpSession session) throws Exception {
        Long userId = (Long) session.getAttribute("USER_ID");
        var created = transactionService.uploadCsv(userId, file, batchName);
        return Map.of("count", created.size());
    }

    @PostMapping("/{id}/submit")
    public Transaction submit(@PathVariable Long id, HttpSession session){
        Long userId = (Long) session.getAttribute("USER_ID");
        Transaction t = new Transaction();
        t.setId(id);
        return transactionService.createOrUpdate(userId, t, true);
    }

    @GetMapping("/approvals")
    public List<Transaction> approvals(HttpSession session){
        Long userId = (Long) session.getAttribute("USER_ID");
        return transactionService.findPendingApprovals(userId);
    }

    @PostMapping("/{id}/approve")
    public Transaction approve(@PathVariable Long id){
        return transactionService.approve(id);
    }

    @PostMapping("/{id}/reject")
    public Transaction reject(@PathVariable Long id){
        return transactionService.reject(id);
    }
}
