package com.example.bank.controller;

import com.example.bank.model.Transaction;
import com.example.bank.repository.TransactionRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class PrintController {
    private final TransactionRepository transactionRepository;

    public PrintController(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @GetMapping("/print")
    public String print(@RequestParam String ids, HttpSession session, Model model){
        Object uid = session.getAttribute("USER_ID");
        if (uid == null) return "redirect:/login.html";
        List<Long> list = Arrays.stream(ids.split(","))
                .map(String::trim).map(Long::valueOf).collect(Collectors.toList());
        List<Transaction> txns = transactionRepository.findAllById(list);
        model.addAttribute("txns", txns);
        return "print";
    }
}
