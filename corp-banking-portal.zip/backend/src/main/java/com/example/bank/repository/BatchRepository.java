package com.example.bank.repository;

import com.example.bank.model.Batch;
import com.example.bank.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BatchRepository extends JpaRepository<Batch, Long> {
    List<Batch> findByOwner(User owner);
}
