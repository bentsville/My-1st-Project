package com.example.bank.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;

@Entity @Table(name="transactions")
@Getter @Setter
public class Transaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    private User owner;

    @ManyToOne(optional = false)
    private Account account;

    @ManyToOne
    private Batch batch;

    @Column(nullable = false)
    private String type; // PAY

    @Column(nullable = false)
    private String beneficiaryName;

    @Column(nullable = false)
    private String beneficiaryAccount;

    @Column(nullable = false)
    private BigDecimal amount;

    private String baseCurrency;
    private String accountCurrency;

    @Column(nullable = false)
    private String status = "DRAFT"; // DRAFT, SUBMITTED, APPROVED, REJECTED, PROCESSED

    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();

    @PreUpdate
    public void onUpdate() { this.updatedAt = Instant.now(); }
}
