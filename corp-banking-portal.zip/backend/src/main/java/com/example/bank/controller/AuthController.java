package com.example.bank.controller;

import com.example.bank.model.User;
import com.example.bank.service.AuthService;
import com.example.bank.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.constraints.NotBlank;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    public AuthController(AuthService authService, UserRepository userRepository) {
        this.authService = authService;
        this.userRepository = userRepository;
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String,String> payload, HttpSession session) {
        String username = payload.get("username");
        String password = payload.get("password");
        var result = authService.login(username, password);
        if (result.success) {
            session.setAttribute("USER_ID", result.userId);
            session.setAttribute("ROLE", result.role);
        }
        return Map.of("success", result.success, "message", result.message);
    }

    @GetMapping("/logout")
    public Map<String, String> logout(HttpSession session) {
        session.invalidate();
        return Map.of("message", "Logged out");
    }

    @GetMapping("/me")
    public Map<String, Object> me(HttpSession session) {
        Object uid = session.getAttribute("USER_ID");
        return Map.of("userId", uid == null ? null : uid);
    }
}
