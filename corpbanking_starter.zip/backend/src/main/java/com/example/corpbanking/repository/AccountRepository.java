
package com.example.corpbanking.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.corpbanking.model.Account;
import com.example.corpbanking.model.AppUser;
public interface AccountRepository extends JpaRepository<Account, Long> {
    List<Account> findByUser(AppUser user);
}
