
package com.example.corpbanking.controller;

import com.example.corpbanking.model.*;
import com.example.corpbanking.repository.AppUserRepository;
import com.example.corpbanking.service.PayrollService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

record PayrollItemDTO(@NotBlank String payeeName, @NotBlank String bankName, @NotBlank String accountNo,
                      @Positive BigDecimal amount, String recipientReference) {}
record CreatePayrollRequest(@NotNull Long accountId, @NotBlank String currency, @Valid List<PayrollItemDTO> items) {}
record IdResponse(Long id) {}

@RestController
@RequestMapping("/api/payroll")
public class PayrollController {
    private final PayrollService payrollService;
    private final AppUserRepository userRepo;

    public PayrollController(PayrollService payrollService, AppUserRepository userRepo) {
        this.payrollService = payrollService;
        this.userRepo = userRepo;
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@AuthenticationPrincipal UserDetails principal, @RequestBody @Valid CreatePayrollRequest req) {
        AppUser u = userRepo.findByUsername(principal.getUsername()).orElseThrow();
        List<PayrollItem> items = new ArrayList<>();
        for (PayrollItemDTO d : req.items()) {
            PayrollItem i = new PayrollItem();
            i.setPayeeName(d.payeeName());
            i.setBankName(d.bankName());
            i.setAccountNo(d.accountNo());
            i.setAmount(d.amount());
            i.setRecipientReference(d.recipientReference());
            items.add(i);
        }
        PayrollBatch b = payrollService.createDraft(req.accountId(), req.currency(), u, items);
        return ResponseEntity.ok(new IdResponse(b.getId()));
    }

    @PostMapping(value="/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> upload(@AuthenticationPrincipal UserDetails principal,
                                    @RequestParam Long accountId,
                                    @RequestParam String currency,
                                    @RequestParam("file") MultipartFile file) throws Exception {
        AppUser u = userRepo.findByUsername(principal.getUsername()).orElseThrow();
        List<PayrollItem> items = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            // CSV header: payeeName,bankName,accountNo,amount,recipientReference
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty() || line.toLowerCase().startsWith("payee")) continue;
                String[] parts = line.split(",");
                PayrollItem i = new PayrollItem();
                i.setPayeeName(parts[0].trim());
                i.setBankName(parts[1].trim());
                i.setAccountNo(parts[2].trim());
                i.setAmount(new BigDecimal(parts[3].trim()));
                if (parts.length>4) i.setRecipientReference(parts[4].trim());
                items.add(i);
            }
        }
        PayrollBatch b = payrollService.createDraft(accountId, currency, u, items);
        return ResponseEntity.ok(new IdResponse(b.getId()));
    }

    @PostMapping("/{id}/submit")
    public ResponseEntity<?> submit(@PathVariable Long id) {
        return ResponseEntity.ok(payrollService.submitForApproval(id));
    }

    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approve(@PathVariable Long id) {
        return ResponseEntity.ok(payrollService.approve(id));
    }

    @GetMapping
    public ResponseEntity<?> list() {
        return ResponseEntity.ok(payrollService.allBatches());
    }
}
