
package com.example.corpbanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorpBankingApplication {
    public static void main(String[] args) {
        SpringApplication.run(CorpBankingApplication.class, args);
    }
}
