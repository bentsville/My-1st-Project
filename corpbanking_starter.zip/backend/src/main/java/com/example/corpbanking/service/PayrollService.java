
package com.example.corpbanking.service;

import com.example.corpbanking.model.*;
import com.example.corpbanking.repository.AccountRepository;
import com.example.corpbanking.repository.PayrollBatchRepository;
import com.example.corpbanking.repository.PayrollItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class PayrollService {
    private final PayrollBatchRepository batchRepo;
    private final PayrollItemRepository itemRepo;
    private final AccountRepository accountRepo;

    public PayrollService(PayrollBatchRepository batchRepo, PayrollItemRepository itemRepo, AccountRepository accountRepo) {
        this.batchRepo = batchRepo;
        this.itemRepo = itemRepo;
        this.accountRepo = accountRepo;
    }

    @Transactional
    public PayrollBatch createDraft(Long accountId, String currency, AppUser creator, List<PayrollItem> items) {
        Account acc = accountRepo.findById(accountId).orElseThrow();
        PayrollBatch b = new PayrollBatch();
        b.setAccount(acc);
        b.setCurrency(currency);
        b.setCreatedBy(creator);
        BigDecimal total = items.stream().map(PayrollItem::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        b.setTotalAmount(total);
        b = batchRepo.save(b);
        for (PayrollItem it : items) {
            it.setBatch(b);
            itemRepo.save(it);
        }
        return b;
    }

    public PayrollBatch submitForApproval(Long batchId) {
        PayrollBatch b = batchRepo.findById(batchId).orElseThrow();
        b.setStatus(TxnStatus.PENDING_APPROVAL);
        return batchRepo.save(b);
    }

    public PayrollBatch approve(Long batchId) {
        PayrollBatch b = batchRepo.findById(batchId).orElseThrow();
        b.setStatus(TxnStatus.APPROVED);
        return batchRepo.save(b);
    }

    public List<PayrollBatch> allBatches() {
        return batchRepo.findAll();
    }
}
