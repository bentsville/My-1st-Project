
package com.example.corpbanking.service;

import com.example.corpbanking.model.AppUser;
import com.example.corpbanking.repository.AppUserRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserService implements UserDetailsService {
    private final AppUserRepository repo;
    private final PasswordEncoder encoder;

    public UserService(AppUserRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser u = repo.findByUsername(username).orElseThrow(() -> new UsernameNotFoundException("Not found"));
        if ("LOCKED".equalsIgnoreCase(u.getStatus())) {
            throw new UsernameNotFoundException("Account locked");
        }
        return new User(u.getUsername(), u.getPassword(),
                List.of(new SimpleGrantedAuthority("ROLE_" + u.getRole())));
    }

    @Transactional
    public void recordFailedLogin(String username) {
        repo.findByUsername(username).ifPresent(u -> {
            u.setFailedAttempts(u.getFailedAttempts() + 1);
            if (u.getFailedAttempts() >= 3) {
                u.setStatus("LOCKED");
            }
            repo.save(u);
        });
    }

    @Transactional
    public void resetFailedLogins(String username) {
        repo.findByUsername(username).ifPresent(u -> {
            u.setFailedAttempts(0);
            repo.save(u);
        });
    }

    public AppUser createUser(String username, String password, String role) {
        AppUser u = new AppUser();
        u.setUsername(username);
        u.setPassword(encoder.encode(password));
        u.setRole(role);
        u.setStatus("ACTIVE");
        u.setFailedAttempts(0);
        return repo.save(u);
    }
}
