
package com.example.corpbanking.controller;

import com.example.corpbanking.security.JwtUtils;
import com.example.corpbanking.service.UserService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;

record LoginRequest(@NotBlank String username, @NotBlank String password){}
record LoginResponse(String token){}
record RegisterRequest(String username, String password, String role){}

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthenticationManager authManager;
    private final JwtUtils jwtUtils;
    private final UserService userService;

    public AuthController(AuthenticationManager authManager, JwtUtils jwtUtils, UserService userService) {
        this.authManager = authManager;
        this.jwtUtils = jwtUtils;
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        try {
            authManager.authenticate(new UsernamePasswordAuthenticationToken(req.username(), req.password()));
            userService.resetFailedLogins(req.username());
            String token = jwtUtils.generateToken(req.username());
            return ResponseEntity.ok(new LoginResponse(token));
        } catch (AuthenticationException e) {
            userService.recordFailedLogin(req.username());
            String message = e instanceof BadCredentialsException ? "Invalid credentials" : e.getMessage();
            return ResponseEntity.status(401).body(message);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        return ResponseEntity.ok(userService.createUser(req.username(), req.password(), req.role()));
    }
}
