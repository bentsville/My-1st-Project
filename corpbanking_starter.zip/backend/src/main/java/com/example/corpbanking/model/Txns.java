
package com.example.corpbanking.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public enum TxnStatus { DRAFT, PENDING_APPROVAL, APPROVED, PROCESSING, COMPLETED, FAILED }
public enum TxnType { PAYROLL, TRANSFER, BILLPAY }

@Entity
@Table(name="transaction_hdr")
public class TransactionHdr {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne @JoinColumn(name="account_id")
    private Account account;
    @Enumerated(EnumType.STRING)
    private TxnType type;
    private BigDecimal amount;
    @Enumerated(EnumType.STRING)
    private TxnStatus status = TxnStatus.DRAFT;
    private String reference;
    private Instant createdAt = Instant.now();
    private Instant updatedAt = Instant.now();
    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Account getAccount() { return account; }
    public void setAccount(Account account) { this.account = account; }
    public TxnType getType() { return type; }
    public void setType(TxnType type) { this.type = type; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public TxnStatus getStatus() { return status; }
    public void setStatus(TxnStatus status) { this.status = status; }
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
}

@Entity
public class PayrollBatch {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne @JoinColumn(name="account_id")
    private Account account;
    private String currency;
    @Enumerated(EnumType.STRING)
    private TxnStatus status = TxnStatus.DRAFT;
    @ManyToOne @JoinColumn(name="created_by")
    private AppUser createdBy;
    private BigDecimal totalAmount = BigDecimal.ZERO;
    private Instant createdAt = Instant.now();
    @OneToMany(mappedBy="batch", cascade=CascadeType.ALL, orphanRemoval=true)
    private List<PayrollItem> items = new ArrayList<>();
    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Account getAccount() { return account; }
    public void setAccount(Account account) { this.account = account; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public TxnStatus getStatus() { return status; }
    public void setStatus(TxnStatus status) { this.status = status; }
    public AppUser getCreatedBy() { return createdBy; }
    public void setCreatedBy(AppUser createdBy) { this.createdBy = createdBy; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public void setTotalAmount(BigDecimal totalAmount) { this.totalAmount = totalAmount; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public List<PayrollItem> getItems() { return items; }
    public void setItems(List<PayrollItem> items) { this.items = items; }
}

@Entity
public class PayrollItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne @JoinColumn(name="batch_id")
    private PayrollBatch batch;
    private String payeeName;
    private String bankName;
    private String accountNo;
    private java.math.BigDecimal amount;
    @Enumerated(EnumType.STRING)
    private TxnStatus status = TxnStatus.DRAFT;
    private String recipientReference;

    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public PayrollBatch getBatch() { return batch; }
    public void setBatch(PayrollBatch batch) { this.batch = batch; }
    public String getPayeeName() { return payeeName; }
    public void setPayeeName(String payeeName) { this.payeeName = payeeName; }
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    public String getAccountNo() { return accountNo; }
    public void setAccountNo(String accountNo) { this.accountNo = accountNo; }
    public java.math.BigDecimal getAmount() { return amount; }
    public void setAmount(java.math.BigDecimal amount) { this.amount = amount; }
    public TxnStatus getStatus() { return status; }
    public void setStatus(TxnStatus status) { this.status = status; }
    public String getRecipientReference() { return recipientReference; }
    public void setRecipientReference(String recipientReference) { this.recipientReference = recipientReference; }
}
