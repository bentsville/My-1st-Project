
package com.example.corpbanking.controller;

import com.example.corpbanking.model.Account;
import com.example.corpbanking.model.AppUser;
import com.example.corpbanking.repository.AppUserRepository;
import com.example.corpbanking.service.AccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
    private final AccountService accountService;
    private final AppUserRepository userRepo;

    public AccountController(AccountService accountService, AppUserRepository userRepo) {
        this.accountService = accountService;
        this.userRepo = userRepo;
    }

    @GetMapping
    public ResponseEntity<List<Account>> myAccounts(@AuthenticationPrincipal UserDetails principal) {
        AppUser u = userRepo.findByUsername(principal.getUsername()).orElseThrow();
        return ResponseEntity.ok(accountService.myAccounts(u));
    }
}
