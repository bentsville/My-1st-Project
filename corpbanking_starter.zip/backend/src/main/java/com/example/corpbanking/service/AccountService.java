
package com.example.corpbanking.service;

import com.example.corpbanking.model.*;
import com.example.corpbanking.repository.AccountRepository;
import com.example.corpbanking.repository.TransactionHdrRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class AccountService {
    private final AccountRepository accountRepo;
    private final TransactionHdrRepository txnRepo;

    public AccountService(AccountRepository accountRepo, TransactionHdrRepository txnRepo) {
        this.accountRepo = accountRepo;
        this.txnRepo = txnRepo;
    }

    public List<Account> myAccounts(AppUser user) {
        return accountRepo.findByUser(user);
    }

    public TransactionHdr createTxn(Account account, BigDecimal amount, TxnType type, String ref) {
        TransactionHdr h = new TransactionHdr();
        h.setAccount(account);
        h.setAmount(amount);
        h.setType(type);
        h.setReference(ref);
        h.setStatus(TxnStatus.DRAFT);
        return txnRepo.save(h);
    }
}
