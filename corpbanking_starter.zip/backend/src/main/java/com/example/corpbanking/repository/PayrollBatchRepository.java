
package com.example.corpbanking.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.corpbanking.model.PayrollBatch;
public interface PayrollBatchRepository extends JpaRepository<PayrollBatch, Long> {}
