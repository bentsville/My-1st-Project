
package com.example.corpbanking.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.corpbanking.model.PayrollItem;
public interface PayrollItemRepository extends JpaRepository<PayrollItem, Long> {}
