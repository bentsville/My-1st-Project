
package com.example.corpbanking.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.corpbanking.model.TransactionHdr;
public interface TransactionHdrRepository extends JpaRepository<TransactionHdr, Long> {}
