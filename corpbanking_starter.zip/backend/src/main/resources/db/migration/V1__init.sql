
-- Users and roles
CREATE TABLE app_user (
  id SERIAL PRIMARY KEY,
  username VARCHAR(64) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(32) NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'ACTIVE',
  failed_attempts INT NOT NULL DEFAULT 0
);
-- Accounts
CREATE TABLE account (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES app_user(id),
  account_number VARCHAR(34) UNIQUE NOT NULL,
  currency VARCHAR(3) NOT NULL,
  balance NUMERIC(18,2) NOT NULL DEFAULT 0
);
-- Transactions
CREATE TYPE txn_status AS ENUM ('DRAFT','PENDING_APPROVAL','APPROVED','PROCESSING','COMPLETED','FAILED');
CREATE TYPE txn_type AS ENUM ('PAYROLL','TRANSFER','BILLPAY');
CREATE TABLE transaction_hdr (
  id SERIAL PRIMARY KEY,
  account_id INT REFERENCES account(id),
  type txn_type NOT NULL,
  amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  status txn_status NOT NULL DEFAULT 'DRAFT',
  reference VARCHAR(64),
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);
-- Payroll
CREATE TABLE payroll_batch (
  id SERIAL PRIMARY KEY,
  account_id INT REFERENCES account(id),
  currency VARCHAR(3) NOT NULL,
  status txn_status NOT NULL DEFAULT 'DRAFT',
  created_by INT REFERENCES app_user(id),
  total_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT now()
);
CREATE TABLE payroll_item (
  id SERIAL PRIMARY KEY,
  batch_id INT REFERENCES payroll_batch(id) ON DELETE CASCADE,
  payee_name VARCHAR(120) NOT NULL,
  bank_name VARCHAR(80) NOT NULL,
  account_no VARCHAR(34) NOT NULL,
  amount NUMERIC(18,2) NOT NULL,
  status txn_status NOT NULL DEFAULT 'DRAFT',
  recipient_reference VARCHAR(64)
);
-- Simple seed
INSERT INTO app_user(username,password,role,status) 
VALUES ('maker', '{bcrypt}$2a$10$1m6Kplr3uP6mNmDNrPko/OH.2fQ3r0E6j3rFJtJTyZ1kU2cB/Yh6e', 'MAKER','ACTIVE'),
       ('checker','{bcrypt}$2a$10$1m6Kplr3uP6mNmDNrPko/OH.2fQ3r0E6j3rFJtJTyZ1kU2cB/Yh6e','CHECKER','ACTIVE');
-- Password for both is: password
INSERT INTO account(user_id, account_number, currency, balance) VALUES
  ((SELECT id FROM app_user WHERE username='maker'),'MY1234567890','MYR',100000.00);
