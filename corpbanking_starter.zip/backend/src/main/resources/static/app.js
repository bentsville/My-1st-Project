
let token = null;
const api = (path, options={}) => fetch(path, Object.assign({
  headers: Object.assign({'Content-Type':'application/json'}, token?{'Authorization':'Bearer '+token}:{})}, options));

async function login(){
  const username = document.getElementById('user').value;
  const password = document.getElementById('pass').value;
  const res = await api('/api/auth/login',{method:'POST', body: JSON.stringify({username,password})});
  const msg = document.getElementById('loginMsg');
  if(res.ok){ const data = await res.json(); token = data.token; msg.textContent='Login success'; 
    document.getElementById('login').style.display='none';
    document.getElementById('dashboard').style.display='block';
    loadAccounts();
  } else { msg.textContent = await res.text(); }
}
async function loadAccounts(){
  const res = await api('/api/accounts');
  const list = document.getElementById('accounts'); list.innerHTML='';
  const data = await res.json();
  data.forEach(a=>{ const li=document.createElement('li'); li.textContent=`#${a.id} ${a.accountNumber} ${a.currency} ${a.balance}`; list.appendChild(li)});
}
async function createPayroll(){
  const accountId = Number(document.getElementById('accId').value);
  const currency = document.getElementById('curr').value;
  const items = JSON.parse(document.getElementById('items').value || '[]');
  const res = await api('/api/payroll/create',{method:'POST', body: JSON.stringify({accountId, currency, items})});
  alert(await res.text()); listBatches();
}
async function uploadCSV(){
  const f = document.getElementById('csv').files[0];
  const accountId = Number(document.getElementById('accId').value);
  const currency = document.getElementById('curr').value;
  const fd = new FormData(); fd.append('file', f); fd.append('accountId', accountId); fd.append('currency', currency);
  const res = await fetch('/api/payroll/upload', {method:'POST', headers: token?{'Authorization':'Bearer '+token}:{}, body: fd});
  alert(await res.text()); listBatches();
}
async function listBatches(){
  const res = await api('/api/payroll');
  const data = await res.json();
  const el = document.getElementById('batches'); el.innerHTML='';
  data.forEach(b=>{
    const div = document.createElement('div');
    div.innerHTML = `<strong>Batch ${b.id}</strong> - ${b.status} - Total ${b.totalAmount} ${b.currency} 
      <button data-id="${b.id}" class="submit">Submit</button>
      <button data-id="${b.id}" class="approve">Approve</button>`;
    el.appendChild(div);
  });
  el.querySelectorAll('.submit').forEach(btn=>btn.onclick=async e=>{
    const id = e.target.dataset.id; await api('/api/payroll/'+id+'/submit',{method:'POST'}); listBatches();
  });
  el.querySelectorAll('.approve').forEach(btn=>btn.onclick=async e=>{
    const id = e.target.dataset.id; await api('/api/payroll/'+id+'/approve',{method:'POST'}); listBatches();
  });
}
