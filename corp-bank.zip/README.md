# Corporate Banking - Lightweight Java HTTP Server (No Spring / No Jakarta Servlet)

## Overview
This project is a lightweight Java 17 web application that demonstrates:
- User login with bcrypt and account lockout after 3 failed attempts
- Create payroll (PAY) transactions (draft/submit)
- CSV upload for quick payment creation
- Transaction listing, simple approval flow
- Account balances and statements
- Static Bootstrap-based frontend pages

**Note:** This sample uses `com.sun.net.httpserver.HttpServer`. For production, use TLS, environment variables for secrets, and a robust web framework.

## How to run
1. Ensure PostgreSQL is running and listening on port **5412**, create database `corporate_bank`.
2. Run `schema.sql` to create tables.
3. Update DB credentials in `src/main/java/com/corpbank/db/DB.java`.
4. Build:
   ```
   mvn clean package
   ```
5. Run:
   ```
   java -jar target/corp-bank-1.0-jar-with-dependencies.jar
   ```
6. Open browser: `http://localhost:8080/static/login.html`

## Files included
- `pom.xml`
- Java sources under `src/main/java/com/corpbank/...`
- Static front-end under `src/main/resources/static/`
- `schema.sql` (DB schema)
