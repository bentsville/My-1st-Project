-- schema.sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE app_user (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  failed_attempts INT DEFAULT 0,
  locked BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE account (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES app_user(id),
  account_number TEXT UNIQUE NOT NULL,
  currency CHAR(3) NOT NULL,
  balance NUMERIC(18,2) DEFAULT 0,
  base_currency_amount NUMERIC(18,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE batch (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES app_user(id),
  name TEXT,
  status TEXT DEFAULT 'OPEN',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE transaction_pay (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  batch_id UUID REFERENCES batch(id),
  created_by UUID REFERENCES app_user(id),
  beneficiary_name TEXT,
  beneficiary_account TEXT,
  amount NUMERIC(18,2) NOT NULL,
  currency CHAR(3) NOT NULL,
  debit_account_id UUID REFERENCES account(id),
  status TEXT DEFAULT 'DRAFT',
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE approval (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  transaction_id UUID REFERENCES transaction_pay(id),
  approver_id UUID REFERENCES app_user(id),
  status TEXT,
  remarks TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE login_session (
  token TEXT PRIMARY KEY,
  user_id UUID REFERENCES app_user(id),
  expires_at TIMESTAMP
);

CREATE TABLE transaction_audit (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  transaction_id UUID REFERENCES transaction_pay(id),
  action TEXT,
  actor UUID REFERENCES app_user(id),
  created_at TIMESTAMP DEFAULT now(),
  note TEXT
);
