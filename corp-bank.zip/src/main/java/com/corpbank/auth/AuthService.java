package com.corpbank.auth;

import com.corpbank.db.DB;
import org.mindrot.jbcrypt.BCrypt;
import java.sql.*;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

public class AuthService {
    private static final int MAX_ATTEMPTS = 3;
    // For demo only. Use env var in production
    private static final String JWT_SECRET = "change_this_to_env_secret";

    public static String login(String username, String password) throws Exception {
        try (Connection c = DB.getConnection()) {
            PreparedStatement ps = c.prepareStatement("SELECT id,password_hash,failed_attempts,locked FROM app_user WHERE username = ?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) throw new Exception("Invalid username or password");

            String id = rs.getString("id");
            String hash = rs.getString("password_hash");
            int attempts = rs.getInt("failed_attempts");
            boolean locked = rs.getBoolean("locked");
            if (locked) throw new Exception("Account locked. Contact admin.");

            boolean ok = BCrypt.checkpw(password, hash);
            if (!ok) {
                attempts++;
                if (attempts >= MAX_ATTEMPTS) {
                    PreparedStatement up = c.prepareStatement("UPDATE app_user SET failed_attempts=?, locked=true WHERE id=?");
                    up.setInt(1, attempts);
                    up.setObject(2, java.util.UUID.fromString(id));
                    up.executeUpdate();
                    throw new Exception("Account locked after 3 failed attempts");
                } else {
                    PreparedStatement up = c.prepareStatement("UPDATE app_user SET failed_attempts=? WHERE id=?");
                    up.setInt(1, attempts);
                    up.setObject(2, java.util.UUID.fromString(id));
                    up.executeUpdate();
                    throw new Exception("Invalid username or password");
                }
            } else {
                PreparedStatement up = c.prepareStatement("UPDATE app_user SET failed_attempts=0 WHERE id=?");
                up.setObject(1, java.util.UUID.fromString(id));
                up.executeUpdate();

                Algorithm alg = Algorithm.HMAC256(JWT_SECRET);
                String token = JWT.create()
                    .withSubject(id)
                    .withClaim("username", username)
                    .withExpiresAt(Date.from(Instant.now().plus(8, ChronoUnit.HOURS)))
                    .sign(alg);

                PreparedStatement ins = c.prepareStatement("INSERT INTO login_session(token,user_id,expires_at) VALUES(?,?,?)");
                ins.setString(1, token);
                ins.setObject(2, java.util.UUID.fromString(id));
                ins.setTimestamp(3, Timestamp.from(Instant.now().plus(8, ChronoUnit.HOURS)));
                ins.executeUpdate();

                return token;
            }
        }
    }

    public static boolean verifyToken(String token) {
        try {
            Algorithm alg = Algorithm.HMAC256(JWT_SECRET);
            com.auth0.jwt.JWTVerifier verifier = JWT.require(alg).build();
            com.auth0.jwt.interfaces.DecodedJWT jwt = verifier.verify(token);
            try (Connection c = DB.getConnection()) {
                PreparedStatement ps = c.prepareStatement("SELECT 1 FROM login_session WHERE token=? AND expires_at > now()");
                ps.setString(1, token);
                ResultSet rs = ps.executeQuery();
                return rs.next();
            }
        } catch(Exception e) {
            return false;
        }
    }

    public static String getUserIdFromToken(String token) {
        try {
            Algorithm alg = Algorithm.HMAC256(JWT_SECRET);
            com.auth0.jwt.JWTVerifier verifier = JWT.require(alg).build();
            com.auth0.jwt.interfaces.DecodedJWT jwt = verifier.verify(token);
            return jwt.getSubject();
        } catch(Exception e) {
            return null;
        }
    }
}
