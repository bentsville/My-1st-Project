package com.corpbank.http;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.*;
import java.nio.file.*;
import java.net.URL;
import java.util.Objects;

public class Router {
    public static void registerRoutes(HttpServer server) {
        server.createContext("/api/login", new com.corpbank.handlers.LoginHandler());
        server.createContext("/api/transactions", new com.corpbank.handlers.TransactionHandler());
        server.createContext("/api/upload", new com.corpbank.handlers.FileUploadHandler());
        server.createContext("/api/approvals", new com.corpbank.handlers.ApprovalHandler());
        server.createContext("/api/accounts", new com.corpbank.handlers.AccountHandler());
    }

    public static void serveStatic(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath().replaceFirst("/static", "");
        if (path.equals("") || path.equals("/")) path = "/login.html";

        ClassLoader cl = Router.class.getClassLoader();
        URL resource = cl.getResource("static" + path);
        if (resource == null) {
            exchange.sendResponseHeaders(404, -1);
            return;
        }
        Path p = Paths.get(resource.getPath());
        byte[] bytes = Files.readAllBytes(p);
        String contentType = Files.probeContentType(p);
        exchange.getResponseHeaders().set("Content-Type", contentType == null ? "application/octet-stream" : contentType);
        exchange.sendResponseHeaders(200, bytes.length);
        OutputStream os = exchange.getResponseBody();
        os.write(bytes);
        os.close();
    }
}
