package com.corpbank.db;

import java.sql.*;
import java.util.Properties;

public class DB {
    // Update these values for your environment
    private static final String URL = "jdbc:postgresql://localhost:5412/corporate_bank";
    private static final String USER = "postgres";
    private static final String PASS = "your_db_password";

    static {
        try {
            Class.forName("org.postgresql.Driver");
        } catch(Exception e) { throw new RuntimeException(e); }
    }

    public static Connection getConnection() throws SQLException {
        Properties props = new Properties();
        props.setProperty("user", USER);
        props.setProperty("password", PASS);
        props.setProperty("stringtype", "unspecified");
        return DriverManager.getConnection(URL, props);
    }
}
