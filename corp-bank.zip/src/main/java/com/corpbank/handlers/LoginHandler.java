package com.corpbank.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.corpbank.auth.AuthService;
import java.io.*;
import com.corpbank.util.JsonUtil;
import java.util.Map;

public class LoginHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }
        Map<String, Object> body = JsonUtil.readJson(exchange.getRequestBody());
        String username = (String)body.get("username");
        String password = (String)body.get("password");
        try {
            String token = com.corpbank.auth.AuthService.login(username, password);
            String resp = JsonUtil.toJson(java.util.Map.of("ok", true, "token", token));
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, resp.getBytes().length);
            exchange.getResponseBody().write(resp.getBytes());
            exchange.close();
        } catch(Exception e) {
            String resp = JsonUtil.toJson(java.util.Map.of("ok", false, "error", e.getMessage()));
            exchange.getResponseHeaders().set("Content-Type", "application/json");
            exchange.sendResponseHeaders(400, resp.getBytes().length);
            exchange.getResponseBody().write(resp.getBytes());
            exchange.close();
        }
    }
}
