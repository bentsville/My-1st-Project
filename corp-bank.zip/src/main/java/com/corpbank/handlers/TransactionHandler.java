package com.corpbank.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.corpbank.util.JsonUtil;
import com.corpbank.auth.AuthService;
import com.corpbank.db.DB;
import java.io.*;
import java.sql.*;
import java.util.*;

public class TransactionHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        if ("POST".equalsIgnoreCase(method)) {
            handleCreate(exchange);
        } else if ("GET".equalsIgnoreCase(method)) {
            handleList(exchange);
        } else {
            exchange.sendResponseHeaders(405, -1);
        }
    }

    private void handleCreate(HttpExchange exchange) throws IOException {
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        String token = extractToken(auth);
        if (token == null || !AuthService.verifyToken(token)) {
            sendJson(exchange, 401, Map.of("ok", false, "error", "Unauthorized"));
            return;
        }
        String userId = AuthService.getUserIdFromToken(token);
        Map<String,Object> body = JsonUtil.readJson(exchange.getRequestBody());
        String action = (String)body.getOrDefault("action", "DRAFT");
        String batchName = (String)body.getOrDefault("batchName", "Payroll - " + System.currentTimeMillis());
        String beneficiary = (String)body.get("beneficiary_name");
        String benAccount = (String)body.get("beneficiary_account");
        Double amount = (body.get("amount") instanceof Number) ? ((Number)body.get("amount")).doubleValue() : null;
        String currency = (String)body.getOrDefault("currency", "MYR");
        String debitAccountId = (String)body.get("debit_account_id");
        if (beneficiary == null || benAccount == null || amount == null || amount <= 0 || debitAccountId == null) {
            sendJson(exchange, 400, Map.of("ok", false, "error", "Missing or invalid fields"));
            return;
        }

        try (Connection c = DB.getConnection()) {
            // create or get batch
            PreparedStatement ps = c.prepareStatement(
                "INSERT INTO batch(user_id,name,status) VALUES(?,?,?) RETURNING id"
            );
            ps.setObject(1, java.util.UUID.fromString(userId));
            ps.setString(2, batchName);
            ps.setString(3, "OPEN");
            ResultSet rs = ps.executeQuery();
            String batchId = null;
            if (rs.next()) batchId = rs.getString(1);

            PreparedStatement ins = c.prepareStatement(
                "INSERT INTO transaction_pay(batch_id,created_by,beneficiary_name,beneficiary_account,amount,currency,debit_account_id,status) VALUES(?,?,?,?,?,?,?,?) RETURNING id"
            );
            ins.setObject(1, java.util.UUID.fromString(batchId));
            ins.setObject(2, java.util.UUID.fromString(userId));
            ins.setString(3, beneficiary);
            ins.setString(4, benAccount);
            ins.setBigDecimal(5, java.math.BigDecimal.valueOf(amount));
            ins.setString(6, currency);
            ins.setObject(7, java.util.UUID.fromString(debitAccountId));
            ins.setString(8, action.equalsIgnoreCase("SUBMIT") ? "SUBMITTED" : "DRAFT");
            ResultSet r2 = ins.executeQuery();
            String txId = null;
            if (r2.next()) txId = r2.getString(1);

            sendJson(exchange, 200, Map.of("ok", true, "transactionId", txId));
        } catch(Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
        }
    }

    private void handleList(HttpExchange exchange) throws IOException {
        String query = exchange.getRequestURI().getQuery();
        Map<String,String> q = parseQuery(query);
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        String token = extractToken(auth);
        if (token == null || !AuthService.verifyToken(token)) {
            sendJson(exchange, 401, Map.of("ok", false, "error", "Unauthorized"));
            return;
        }
        String userId = AuthService.getUserIdFromToken(token);
        boolean mineOnly = "true".equalsIgnoreCase(q.getOrDefault("mine","true"));
        try (Connection c = DB.getConnection()) {
            PreparedStatement ps;
            if (mineOnly) {
                ps = c.prepareStatement("SELECT id,beneficiary_name,beneficiary_account,amount,currency,status,created_at FROM transaction_pay WHERE created_by = ? ORDER BY created_at DESC");
                ps.setObject(1, java.util.UUID.fromString(userId));
            } else {
                ps = c.prepareStatement("SELECT id,beneficiary_name,beneficiary_account,amount,currency,status,created_at FROM transaction_pay ORDER BY created_at DESC");
            }
            ResultSet rs = ps.executeQuery();
            java.util.List<Map<String,Object>> list = new ArrayList<>();
            while (rs.next()) {
                Map<String,Object> m = new HashMap<>();
                m.put("id", rs.getString("id"));
                m.put("beneficiary_name", rs.getString("beneficiary_name"));
                m.put("beneficiary_account", rs.getString("beneficiary_account"));
                m.put("amount", rs.getBigDecimal("amount"));
                m.put("currency", rs.getString("currency"));
                m.put("status", rs.getString("status"));
                m.put("created_at", rs.getTimestamp("created_at").toString());
                list.add(m);
            }
            sendJson(exchange, 200, Map.of("ok", true, "transactions", list));
        } catch(Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
        }
    }

    private void sendJson(HttpExchange exchange, int code, Object obj) throws IOException {
        String resp = JsonUtil.toJson(obj);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        byte[] b = resp.getBytes();
        exchange.sendResponseHeaders(code, b.length);
        exchange.getResponseBody().write(b);
        exchange.close();
    }

    private String extractToken(String auth) {
        if (auth == null) return null;
        if (auth.startsWith("Bearer ")) return auth.substring(7);
        return null;
    }

    private Map<String,String> parseQuery(String q) {
        Map<String,String> m = new HashMap<>();
        if (q == null) return m;
        for (String part : q.split("&")) {
            String[] kv = part.split("=",2);
            if (kv.length==2) m.put(kv[0], kv[1]);
        }
        return m;
    }
}
