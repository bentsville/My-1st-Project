package com.corpbank.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.corpbank.auth.AuthService;
import com.corpbank.db.DB;
import com.corpbank.util.JsonUtil;
import java.io.*;
import java.sql.*;
import java.util.*;

public class ApprovalHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        String token = extractToken(auth);
        if (token == null || !AuthService.verifyToken(token)) {
            sendJson(exchange, 401, Map.of("ok", false, "error", "Unauthorized")); return;
        }
        String userId = AuthService.getUserIdFromToken(token);

        if ("GET".equalsIgnoreCase(method)) {
            // list submitted transactions
            try (Connection c = DB.getConnection()) {
                PreparedStatement ps = c.prepareStatement("SELECT id,beneficiary_name,beneficiary_account,amount,currency,created_at FROM transaction_pay WHERE status = 'SUBMITTED' ORDER BY created_at");
                ResultSet rs = ps.executeQuery();
                List<Map<String,Object>> list = new ArrayList<>();
                while (rs.next()) {
                    Map<String,Object> m = new HashMap<>();
                    m.put("id", rs.getString("id"));
                    m.put("beneficiary_name", rs.getString("beneficiary_name"));
                    m.put("beneficiary_account", rs.getString("beneficiary_account"));
                    m.put("amount", rs.getBigDecimal("amount"));
                    m.put("currency", rs.getString("currency"));
                    m.put("created_at", rs.getTimestamp("created_at").toString());
                    list.add(m);
                }
                sendJson(exchange, 200, Map.of("ok", true, "submitted", list));
            } catch(Exception e) {
                e.printStackTrace();
                sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
            }
        } else if ("POST".equalsIgnoreCase(method)) {
            Map<String,Object> body = JsonUtil.readJson(exchange.getRequestBody());
            String txId = (String)body.get("transactionId");
            String action = ((String)body.get("action")).toUpperCase();
            String remarks = (String)body.getOrDefault("remarks", "");
            if (txId == null || (!action.equals("APPROVE") && !action.equals("REJECT"))) {
                sendJson(exchange, 400, Map.of("ok", false, "error", "Invalid request"));
                return;
            }
            try (Connection c = DB.getConnection()) {
                PreparedStatement ps = c.prepareStatement("INSERT INTO approval(transaction_id,approver_id,status,remarks) VALUES(?,?,?,?)");
                ps.setObject(1, java.util.UUID.fromString(txId));
                ps.setObject(2, java.util.UUID.fromString(userId));
                ps.setString(3, action.equals("APPROVE") ? "APPROVED" : "REJECTED");
                ps.setString(4, remarks);
                ps.executeUpdate();

                PreparedStatement up = c.prepareStatement("UPDATE transaction_pay SET status=? WHERE id=?");
                up.setString(1, action.equals("APPROVE") ? "APPROVED" : "REJECTED");
                up.setObject(2, java.util.UUID.fromString(txId));
                up.executeUpdate();

                sendJson(exchange, 200, Map.of("ok", true));
            } catch(Exception e) {
                e.printStackTrace();
                sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
            }
        } else {
            exchange.sendResponseHeaders(405, -1);
        }
    }

    private void sendJson(HttpExchange exchange, int code, Object obj) throws IOException {
        String resp = JsonUtil.toJson(obj);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        byte[] b = resp.getBytes();
        exchange.sendResponseHeaders(code, b.length);
        exchange.getResponseBody().write(b);
        exchange.close();
    }

    private String extractToken(String auth) {
        if (auth == null) return null;
        if (auth.startsWith("Bearer ")) return auth.substring(7);
        return null;
    }
}
