package com.corpbank.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.corpbank.auth.AuthService;
import com.corpbank.db.DB;
import com.corpbank.util.JsonUtil;
import org.apache.commons.csv.*;
import java.io.*;
import java.sql.*;
import java.util.*;

public class FileUploadHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(405, -1); return;
        }
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        String token = extractToken(auth);
        if (token == null || !AuthService.verifyToken(token)) {
            sendJson(exchange, 401, Map.of("ok", false, "error", "Unauthorized")); return;
        }
        String userId = AuthService.getUserIdFromToken(token);
        // read multipart raw data (simple approach: read full body and look for CSV content)
        InputStream is = exchange.getRequestBody();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = is.read(buf)) != -1) baos.write(buf,0,r);
        byte[] data = baos.toByteArray();
        // For simplicity assume body is the CSV content (not strict multipart handling).
        try (Reader reader = new InputStreamReader(new ByteArrayInputStream(data), "UTF-8")) {
            CSVFormat fmt = CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreEmptyLines(true).withTrim();
            Iterable<CSVRecord> records = fmt.parse(reader);
            int created = 0; List<Map<String,Object>> errors = new ArrayList<>();
            try (Connection c = DB.getConnection()) {
                // create a batch
                PreparedStatement ps = c.prepareStatement("INSERT INTO batch(user_id,name,status) VALUES(?,?,?) RETURNING id");
                ps.setObject(1, java.util.UUID.fromString(userId));
                ps.setString(2, "CSV Upload " + System.currentTimeMillis());
                ps.setString(3, "OPEN");
                ResultSet br = ps.executeQuery();
                String batchId = null;
                if (br.next()) batchId = br.getString(1);

                PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO transaction_pay(batch_id,created_by,beneficiary_name,beneficiary_account,amount,currency,debit_account_id,status) VALUES(?,?,?,?,?,?,?,?)"
                );
                for (CSVRecord rec : records) {
                    String ben = rec.get("beneficiary_name");
                    String benAcc = rec.get("beneficiary_account");
                    String amtStr = rec.get("amount");
                    String currency = rec.isMapped("currency") ? rec.get("currency") : "MYR";
                    String debitAccNum = rec.isMapped("debit_account_number") ? rec.get("debit_account_number") : null;
                    if (ben==null || benAcc==null || amtStr==null || amtStr.isBlank()) {
                        errors.add(Map.of("row", rec.getRecordNumber(), "error", "Missing required fields")); continue;
                    }
                    double amt;
                    try { amt = Double.parseDouble(amtStr); } catch(Exception ex) {
                        errors.add(Map.of("row", rec.getRecordNumber(), "error", "Invalid amount")); continue;
                    }
                    // resolve debit account id by account_number
                    String debitAccountId = null;
                    if (debitAccNum != null && !debitAccNum.isBlank()) {
                        PreparedStatement q = c.prepareStatement("SELECT id FROM account WHERE account_number = ?");
                        q.setString(1, debitAccNum);
                        ResultSet qr = q.executeQuery();
                        if (qr.next()) debitAccountId = qr.getString(1);
                    }
                    if (debitAccountId == null) {
                        errors.add(Map.of("row", rec.getRecordNumber(), "error", "Debit account not found")); continue;
                    }
                    ins.setObject(1, java.util.UUID.fromString(batchId));
                    ins.setObject(2, java.util.UUID.fromString(userId));
                    ins.setString(3, ben);
                    ins.setString(4, benAcc);
                    ins.setBigDecimal(5, java.math.BigDecimal.valueOf(amt));
                    ins.setString(6, currency);
                    ins.setObject(7, java.util.UUID.fromString(debitAccountId));
                    ins.setString(8, "DRAFT");
                    ins.executeUpdate();
                    created++;
                }
            }
            sendJson(exchange, 200, Map.of("ok", true, "created", created, "errors", errors));
        } catch(Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
        }
    }

    private void sendJson(HttpExchange exchange, int code, Object obj) throws IOException {
        String resp = JsonUtil.toJson(obj);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        byte[] b = resp.getBytes();
        exchange.sendResponseHeaders(code, b.length);
        exchange.getResponseBody().write(b);
        exchange.close();
    }

    private String extractToken(String auth) {
        if (auth == null) return null;
        if (auth.startsWith("Bearer ")) return auth.substring(7);
        return null;
    }
}
