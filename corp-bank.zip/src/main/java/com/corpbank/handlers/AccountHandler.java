package com.corpbank.handlers;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.corpbank.auth.AuthService;
import com.corpbank.db.DB;
import com.corpbank.util.JsonUtil;
import java.io.*;
import java.sql.*;
import java.util.*;

public class AccountHandler implements HttpHandler {
    public void handle(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod();
        String auth = exchange.getRequestHeaders().getFirst("Authorization");
        String token = extractToken(auth);
        if (token == null || !AuthService.verifyToken(token)) {
            sendJson(exchange, 401, Map.of("ok", false, "error", "Unauthorized")); return;
        }
        String userId = AuthService.getUserIdFromToken(token);

        if ("GET".equalsIgnoreCase(method)) {
            String path = exchange.getRequestURI().getPath();
            if (path.matches(".*/accounts/[^/]+/statement")) {
                handleStatement(exchange, userId); return;
            }
            try (Connection c = DB.getConnection()) {
                PreparedStatement ps = c.prepareStatement("SELECT id,account_number,currency,balance FROM account WHERE user_id = ?");
                ps.setObject(1, java.util.UUID.fromString(userId));
                ResultSet rs = ps.executeQuery();
                List<Map<String,Object>> accs = new ArrayList<>();
                while (rs.next()) {
                    accs.add(Map.of(
                        "id", rs.getString("id"),
                        "account_number", rs.getString("account_number"),
                        "currency", rs.getString("currency"),
                        "balance", rs.getBigDecimal("balance")
                    ));
                }
                sendJson(exchange, 200, Map.of("ok", true, "accounts", accs));
            } catch(Exception e) {
                e.printStackTrace();
                sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
            }
        } else {
            exchange.sendResponseHeaders(405, -1);
        }
    }

    private void handleStatement(HttpExchange exchange, String userId) throws IOException {
        // simple statement: parse accountId from path, get ?from & ?to
        String path = exchange.getRequestURI().getPath();
        String[] parts = path.split("/");
        String accountId = parts[parts.length-2]; // expected /api/accounts/{id}/statement
        String query = exchange.getRequestURI().getQuery();
        Map<String,String> q = parseQuery(query);
        String from = q.get("from");
        String to = q.get("to");
        try (Connection c = DB.getConnection()) {
            PreparedStatement ps = c.prepareStatement(
                "SELECT id,beneficiary_name,amount,currency,status,created_at FROM transaction_pay WHERE debit_account_id = ? AND created_at >= COALESCE(?, '-infinity') AND created_at <= COALESCE(?, 'infinity') ORDER BY created_at"
            );
            ps.setObject(1, java.util.UUID.fromString(accountId));
            if (from != null) ps.setString(2, from); else ps.setNull(2, Types.VARCHAR);
            if (to != null) ps.setString(3, to); else ps.setNull(3, Types.VARCHAR);
            ResultSet rs = ps.executeQuery();
            List<Map<String,Object>> tx = new ArrayList<>();
            while (rs.next()) {
                tx.add(Map.of(
                    "id", rs.getString("id"),
                    "beneficiary_name", rs.getString("beneficiary_name"),
                    "amount", rs.getBigDecimal("amount"),
                    "currency", rs.getString("currency"),
                    "status", rs.getString("status"),
                    "created_at", rs.getTimestamp("created_at").toString()
                ));
            }
            sendJson(exchange, 200, Map.of("ok", true, "statement", tx));
        } catch(Exception e) {
            e.printStackTrace();
            sendJson(exchange, 500, Map.of("ok", false, "error", e.getMessage()));
        }
    }

    private void sendJson(HttpExchange exchange, int code, Object obj) throws IOException {
        String resp = JsonUtil.toJson(obj);
        exchange.getResponseHeaders().set("Content-Type", "application/json");
        byte[] b = resp.getBytes();
        exchange.sendResponseHeaders(code, b.length);
        exchange.getResponseBody().write(b);
        exchange.close();
    }

    private String extractToken(String auth) {
        if (auth == null) return null;
        if (auth.startsWith("Bearer ")) return auth.substring(7);
        return null;
    }

    private Map<String,String> parseQuery(String q) {
        Map<String,String> m = new HashMap<>();
        if (q == null) return m;
        for (String part : q.split("&")) {
            String[] kv = part.split("=",2);
            if (kv.length==2) m.put(kv[0], kv[1]);
        }
        return m;
    }
}
